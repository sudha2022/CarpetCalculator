

	public interface CarpetCalculatable{
		void addRoom(CarpetRoomArea room);
	    String getTotalCost();
	    void addPercentDiscount(float percentDiscount);
	
}
